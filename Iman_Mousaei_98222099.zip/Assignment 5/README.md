# Assignment 5

## TODO

- theory✅
- optimizers code✅
- plot optimizers regression line
- animate 2d
- animate 3d ❌
- time series ❌
- report✅
