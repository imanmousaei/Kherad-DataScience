import pandas as pd

from coreai.utils import cleaners, recom, consts, cluster
import coreai


# because of sanctions,vpn,...
# we got Error 400
# ergo we could not use Spotify API
# so we simulated it.


def get_recommendations(playlist):
    # number of rows we want to work with(because the dataset is too large to cluster for my laptop)
    maxn = int(consts.maxn)
    path = "coreai/datasets/genres_v2.csv"

    data = pd.read_csv(path)
    data = data.sample(maxn)

    standard_data = data.copy()
    standard_data = cleaners.drop_useless_cols(standard_data)
    standard_data = cleaners.columns2numeric(standard_data, ['genre'])
    # print(data.iloc[0]['id'])
    standard_data = cleaners.unskew(standard_data)
    standard_data = cleaners.normalize(standard_data)
    print("data cleaned")

    # data = data.set_index(keys='id', drop=False)
    # print(data.iloc[0]['id'])

    # generate a random playlist of size playlist_size
    # playlist = [song['id'] for _, song in standard_data.sample(playlist_size).iterrows()]
    # print(playlist)

    cleaned_data = standard_data.drop(['id'], axis=1)
    # choose your desired method for clustering
    clustering_method = 'kmeans'
    labels = cluster.cluster_by_name(cleaned_data, clustering_method)
    # print("labels after clustering: ", labels)

    recommendations = recom.get_k_recommendations(standard_data, playlist, labels, k=5)
    # print(recommendations)

    ans = data.loc[data['id'].isin(recommendations)]
    # print(ans)

    return ans
