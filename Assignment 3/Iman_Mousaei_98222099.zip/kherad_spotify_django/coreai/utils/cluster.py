import pickle

from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering


def cluster_by_name(data, clustering_method):
    """
    :param clustering_method: supported methods are: kmeans, dbscan, agglomerativeclustering
    :return: labels of data after clustering
    """
    clustering_method = clustering_method.lower()
    if clustering_method == "kmeans":
        model = kmeans(data)
    elif clustering_method == "dbscan":
        model = dbscan(data)
    elif clustering_method == "agglomerativeclustering":
        model = agg_clustering(data)
    else:
        raise Exception("clustering_method is not supported")

    return model.labels_


def kmeans(data):
    model = KMeans(n_clusters=5, random_state=0).fit(data)
    return model
    # kmeans.predict(point)
    # kmeans.cluster_centers_


def dbscan(data):
    model = DBSCAN(eps=3, min_samples=2).fit(data)
    return model
    # clustering.fit_predict(point)


def agg_clustering(data):
    model = AgglomerativeClustering().fit(data)
    return model
    # clustering.fit_predict(point)
