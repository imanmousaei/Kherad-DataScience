import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats


def normal_report(data):
    normal  = stats.normaltest(data)
    skew    = stats.skewtest(data)
    kurtosis= stats.kurtosistest(data)
    tests   = [normal, skew, kurtosis]
    names   = ['']
    res     =   pd.DataFrame({'score': normal[0], 'pvalue': normal[1]}, index=data.columns)
    for test in tests[1:]:
        temp = pd.DataFrame({f'{test.__class__.__name__}-score': test[0], f'{test.__class__.__name__}-pvalue': test[1]}, index=data.columns)
        res = res.join(temp)
    return res


def hist_plot_distro(input_data):
  sns.set(rc={'figure.figsize':(15,10)})
  fig, axs = plt.subplots(2, 3)
  plot_cols = ['danceability', 'energy',	'loudness', 'speechiness', 'acousticness',	'instrumentalness']
  for i in [0,1,2]:
    for j in [0,1]:
        sns.histplot(data=input_data[plot_cols], x=plot_cols[i+j*3], bins=20, ax=axs[j, i], kde=True)

  normal_report(input_data[plot_cols]).head(10)