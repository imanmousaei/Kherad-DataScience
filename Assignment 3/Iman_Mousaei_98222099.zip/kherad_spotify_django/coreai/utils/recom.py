import pandas as pd
import numpy as np

from coreai.utils import consts


def dist(point1: pd.DataFrame, point2: pd.DataFrame):
    d = 0
    for col in consts.important_columns:
        d += (point1[col] - point2[col]) ** 2
    return d


def get_k_recommendations(data, playlist, labels, k):
    """
    return k*k nearest songs. distance of a song is defined as the average Euclidean distance between the song and
        its cluster-mates that are in the playlist

    :param data: dataset for clustering
    :param playlist: list of song id to recommend based on it
    :param k: number of songs to recommend
    """

    # list of tuple (distance, index) ; distances[i]: list of distances for songs in cluster i
    distances = [[]] * k

    # list of playlisted songs for each cluster; playlisted_songs[0] = playlisted_songs for cluster 0
    playlisted_songs = [[]] * k

    i = -1
    for _, row in data.iterrows():
        i += 1
        cluster_number = labels[i]
        # print(cluster_number)
        # print(f' l = {len(playlisted_songs)} ')
        if row['id'] in playlist:
            playlisted_songs[cluster_number].append(row)
        distances.append([])

    # print(playlisted_songs)

    i = -1
    for _, row in data.iterrows():
        i += 1
        d = 0
        if i >= consts.maxn:
            break

        cluster_number = labels[i]

        if cluster_number < len(playlisted_songs):
            for ps in playlisted_songs[cluster_number]:
                d += dist(ps, row)
        else:
            d = np.inf

        distances[cluster_number].append((d, i))

    # distances.sort()

    recommendations = []
    for cluster_number in range(k):
        distances[cluster_number].sort()
        for j in range(k):
            if j >= len(distances):
                return

            song = distances[cluster_number][j]
            # print(song)
            song_index = song[1]
            if song_index >= consts.maxn:
                continue
            recommendations.append(data.iloc[song_index]['id'])

    return recommendations
