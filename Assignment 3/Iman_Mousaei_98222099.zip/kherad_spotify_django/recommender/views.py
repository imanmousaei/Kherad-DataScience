from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response

import coreai
import recommender
from coreai.main import get_recommendations


class HomeView(APIView):
    def get(self, request):

        return render(request, 'home.html')


class RecommendView(APIView):
    def post(self, request):
        sample_playlist = ['5NhlpQ6BOIz3S5welptk1W', '7KQvT4YuzcmyogWg7Gq4Z5', '4gnH8nfdJfN115QAzzUc3E', '2PpaDTDhP2HGknitidRySe', '35ZU6gAyAVme40TzvKJKAA', '7vkqAOyzqIHlNy3mHXCglf', '4Ao4XHlqBTKsCil8R6e8fD', '5kU8CmW7jK8CYe5loxfgXR', '5n6R9lNjXey5XNU10upMG2', '2s5MounvV71Esvt4phUgiR', '3TMORdp92ZjkP17syHaqC3', '4kfUw6ge9PxgCWWFVv98ue', '2ts7xbOqPk6aPRpbmDHabN', '5lv9NHfkMTdWxPKyW6SmZx', '0Sd0kdgU6HrIclxYjuV99j', '54V8ZtAQAfbfQTqLMZRUjh', '0gdqECaacwiFCC59yz9aZE', '1ytNxHhF6vMBWFp1hmAbF4', '0jP2aQtS6pp0keleTqfUbS', '1kMuU3TNQvHbqvXCWBodmP']
        sample_input = '5NhlpQ6BOIz3S5welptk1W, 7KQvT4YuzcmyogWg7Gq4Z5, 4gnH8nfdJfN115QAzzUc3E, 2PpaDTDhP2HGknitidRySe, 35ZU6gAyAVme40TzvKJKAA, 7vkqAOyzqIHlNy3mHXCglf, 4Ao4XHlqBTKsCil8R6e8fD, 5kU8CmW7jK8CYe5loxfgXR, 5n6R9lNjXey5XNU10upMG2, 2s5MounvV71Esvt4phUgiR, 3TMORdp92ZjkP17syHaqC3, 4kfUw6ge9PxgCWWFVv98ue, 2ts7xbOqPk6aPRpbmDHabN, 5lv9NHfkMTdWxPKyW6SmZx, 0Sd0kdgU6HrIclxYjuV99j, 54V8ZtAQAfbfQTqLMZRUjh, 0gdqECaacwiFCC59yz9aZE, 1ytNxHhF6vMBWFp1hmAbF4, 0jP2aQtS6pp0keleTqfUbS, 1kMuU3TNQvHbqvXCWBodmP'

        playlist = request.POST['playlist']
        playlist.strip().split(',')

        recommendations = get_recommendations(playlist)
        # print(recommendations['analysis_url'])
        # print(recommendations)

        recommendations = recommendations.to_dict(orient='records')

        # print(recommendations)
        context = {
            'recommendations': recommendations
        }
        return render(request, 'music-list.html', context)


