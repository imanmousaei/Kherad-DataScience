import sys
import os
import pandas as pd

import utils.cluster
from utils import cleaners, recom, consts


def main(args, playlist_size) -> None:
    """ Main function to be called when the script is run from the command line.
    This function will recommend songs based on the user's input and save the
    playlist to a csv file.

    Parameters
    ----------
    args: list
        list of arguments from the command line
    playlist: list
        list of song uri to get your recommendations based on them

    Returns
    -------
    None
    """

    # number of rows we want to work with(because the dataset is too large to cluster for my laptop)
    maxn = int(consts.maxn)
    arg_list = args[1:]
    if len(arg_list) == 0:
        print("using default csv file: datasets/genres_v2.csv")
        path = "datasets/genres_v2.csv"
    else:
        path = arg_list[0]

    if not os.path.isfile(path):
        print("File does not exist")
        sys.exit()

    data = pd.read_csv(path)
    data = data.sample(maxn)

    data = cleaners.drop_useless_cols(data)
    data = cleaners.columns2numeric(data, ['genre'])
    # print(data.iloc[0]['id'])
    data = cleaners.unskew(data)
    data = cleaners.normalize(data)
    print("data cleaned")

    # data = data.set_index(keys='id', drop=False)
    # print(data.iloc[0]['id'])

    # generate a random playlist of size playlist_size
    playlist = [song['id'] for _, song in data.sample(playlist_size).iterrows()]

    cleaned_data = data.drop(['id'], axis=1)
    # choose your desired method for clustering
    clustering_method = 'kmeans'
    labels = utils.cluster.cluster_by_name(cleaned_data, clustering_method)
    print("labels after clustering: ", labels)

    recommendations = recom.get_k_recommendations(data, playlist, labels, k=5)
    # print(recommendations)

    # TODO:
    # 2. Output the recommendations as 5 different playlists with
    #    the top 5 songs in each playlist. (5 playlists x 5 songs)
    # 2.1. Musics in a single playlist should be from the same cluster.
    # 2.2. Save playlists to a csv file.
    # 3. Output another single playlist recommendation with all top songs from all clusters.


if __name__ == "__main__":
    # get arguments from command line
    args = sys.argv
    main(args, 20)
