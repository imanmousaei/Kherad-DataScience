from utils import consts
from utils.skew_autotransform import skew_autotransform


def drop_useless_cols(data):
    data.drop(['track_href', 'song_name', 'uri', 'analysis_url', 'title', 'Unnamed: 0', 'type'], axis=1, inplace=True)
    return data


def unskew(data):
    """
    Converts data into Gaussian distribution
    """
    # print(data.query("audio_features"))
    standard_data = skew_autotransform(data.copy(deep=True), plot=False, exp=False, threshold=0.5, exclude=['id'])
    return standard_data


def normalize(data):
    """
    scale data to range [0,1]
    """
    normal_data = data.copy()

    for column in consts.important_columns:
        normal_data[column] = (normal_data[column] - normal_data[column].min()) / (
                normal_data[column].max() - normal_data[column].min())

    return normal_data


def columns2numeric(data, cols):
    for col in cols:
        data[col] = data[col].astype("category")
        data[col] = data[col].cat.codes
    return data
